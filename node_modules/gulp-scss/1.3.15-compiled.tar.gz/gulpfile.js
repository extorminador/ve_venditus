/*global require*/
(function (r) {
    "use strict";
    r("coffee-script/register");
    r("./gulpfile.coffee");
}(require));
